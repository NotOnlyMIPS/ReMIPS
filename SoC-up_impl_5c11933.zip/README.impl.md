# Version of implementation

git@github.com:NotOnlyMIPS:ReMIPS.git, branch dev

commit 5c11933dea3eccbd0aa7515b35a3acaaaf4cc780
Date:   Mon Aug 14 18:49:26 2023 +0800
	feat: packup soc up rtl & tb temporarily

# Generation log

write_cfgmem -format mcs -interface spix1 -size 16 -loadbit "up 0 soc_up_top.bit" -file soc_up_top.mcs
Command: write_cfgmem -format mcs -interface spix1 -size 16 -loadbit {up 0 soc_up_top.bit} -file soc_up_top.mcs
Creating config memory files...
Creating bitstream load up from address 0x00000000
Loading bitfile soc_up_top.bit
Writing file ./soc_up_top.mcs
Writing log file ./soc_up_top.prm
===================================
Configuration Memory information
===================================
File Format        MCS
Interface          SPIX1
Size               16M
Start Address      0x00000000
End Address        0x00FFFFFF

Addr1         Addr2         Date                    File(s)
0x00000000    0x00947A5B    Aug 14 18:27:22 2023    soc_up_top.bit
0 Infos, 0 Warnings, 0 Critical Warnings and 0 Errors encountered.
write_cfgmem completed successfully
